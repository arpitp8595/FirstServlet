package com.sso.test;

import java.io.IOException;
import java.text.ParseException;
import java.util.logging.Logger;

import com.microsoft.aad.adal4j.AuthenticationResult;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTParser;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "Controller", urlPatterns = "/secure/aad")
public class Controller extends HttpServlet {	
private static final long serialVersionUID = 1L;

	//@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
	@Override
	public void doGet(HttpServletRequest httpRequest, HttpServletResponse response)
	    throws IOException, ServletException {
	Logger log = Logger.getLogger(Controller.class.getName());
		HttpSession session = httpRequest.getSession();
		log.info("session: " + session);
		AuthenticationResult result = (AuthenticationResult) session.getAttribute(CommonUtil.PRINCIPAL_SESSION_NAME);
		if (result == null) {
		  session.setAttribute("error", new Exception("AuthenticationResult not found in session."));
		RequestDispatcher dispatcher = httpRequest.getRequestDispatcher("/error.jsp");
		dispatcher.forward(httpRequest, response);
		return;
		
		} else {
			try {
				log.info("JWT token details:-");
				JWT jwt = JWTParser.parse(result.getIdToken());
				for (String key : jwt.getJWTClaimsSet().getAllClaims().keySet()) {
					log.info(key + ":" + jwt.getJWTClaimsSet().getAllClaims().get(key));
				}
				session.setAttribute("user", jwt.getJWTClaimsSet().getStringClaim("unique_name"));
			} catch (ParseException e) {
				log.info("Exception:");
			}
		}
		RequestDispatcher dispatcher = httpRequest.getRequestDispatcher("hello.jsp");
		dispatcher.forward(httpRequest, response);
		return;
		
	}

}
